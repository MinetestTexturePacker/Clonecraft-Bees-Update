#tg_flatland

flatland is a very boring landscape generator that just generates an absolutely flat surface.  
It DOES utilize biomes if you pass a biomefunc

below is an example of a realms.conf entry that calls flatland:

    tg_flatland      |-33000| 25000|-33000| 33000| 26500| 33000|   26000|bm_mixed_biomes     |

