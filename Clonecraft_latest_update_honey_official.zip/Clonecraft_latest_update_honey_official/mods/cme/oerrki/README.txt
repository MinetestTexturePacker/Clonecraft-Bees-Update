Oerrki for Creatures MOB-Engine
===============================
Copyright (c) 2016 BlockMen <blockmen2015@gmail.com>

Version: 1.0 Beta


Adds classic Minetest Ghost called "Oerrki". (requires Creatures MOB-Engine).
Oerrki spawn only at night or in dark places and remain around 5 minutes in the world.
Other than Ghosts or Zombies they don't die by sunlight.


License:
~~~~~~~~
Code:
(c) Copyright 2016 BlockMen; modified zlib-License
see "LICENSE.txt" for details.

Mesh/Model:
(c) Copyright 2016 BlockMen; CC-BY-SA 3.0
    derivated from Pavel_S's work; WTFPL

Textures:
(c) Copyright Pavel_S; WTFPL

Sounds:
(c) Copyright 2016 BlockMen; CC-BY-SA 3.0


Github:
~~~~~~~
