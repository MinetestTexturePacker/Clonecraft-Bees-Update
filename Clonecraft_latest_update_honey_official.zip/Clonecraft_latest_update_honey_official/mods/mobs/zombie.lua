mobs:register_mob("mobs:zombie", {
	type = "monster",
	visual = "mesh",
	mesh = "mobs_zombie.x",
	textures = {"mobs_zombie.png"},
	collisionbox = {-0.25, -1, -0.3, 0.25, 0.75, 0.3},
	animation = {
		speed_normal = 10,	speed_run = 15,
		stand_start = 0,	stand_end = 79,
		walk_start = 168,	walk_end = 188,
		run_start = 168,	run_end = 188
	},
	makes_footstep_sound = true,
	sounds = {
		random = "mobs_zombie",
		war_cry = "mobs_zombie",
		attack = "mobs_zombie",
		damage = "mobs_zombie_hit",
		death = "mobs_zombie_death",
	},
	hp_min = 15,
	hp_max = 25,
	armor = 100,
	knock_back = 1,
	light_damage = 1,
	lava_damage = 10,
	damage = 2,
	reach = 2,
	attack_type = "dogfight",
--  attack = true,
	view_range = 15,
	walk_chance = 75,
	walk_velocity = 0.5,
	run_velocity = 0.5,
	jump = false,
	drops = {
		{name = "mobs:cooked_rat"},
		{name = "farming:potato", chance = 2},
		{name = "farming:carrot", chance = 2}
	},
	after_activate = function(self, staticdata, def, dtime)
	-- replace zombies using the old directx model
		if self.mesh == "mobs_zombie.x" then
			local pos = self.object:get_pos()
			if pos then
				minetest.add_entity(pos, self.name)
				self.object:remove()
			end
		end
	end,	})

mobs:register_spawn({
	name = "mobs:zombie",
	nodes = {"default:dirt", "default:sandstone", "default:sand", "default:desert_sand", "default:stone", "default:snowblock", "default:dirt_with_snow", "default:dirt_with_grass", "default:dirt_with_dry_grass", "default:cobble", "default:mossycobble"},
	max_light = 10,
	chance = 15000,
	min_height = -64,
})	

mobs:register_egg("mobs:zombie", "Spawn Zombie", "spawn_zombie.png", 0)
