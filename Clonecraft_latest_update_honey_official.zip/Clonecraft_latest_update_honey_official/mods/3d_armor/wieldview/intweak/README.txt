Minetest mod "Inventory Tweak"
=======================
version: 1.0

License of source code: WTFPL
-----------------------------
Written 2013 by BlockMen

This program is free software. It comes without any warranty, to
the extent permitted by applicable law. You can redistribute it
and/or modify it under the terms of the Do What The Fuck You Want
To Public License, Version 2, as published by Sam Hocevar. See
http://sam.zoy.org/wtfpl/COPYING for more details.

License of sounds:
------------------
intweak_break_tool.ogg by EdgardEdition (CC BY 3.0), http://www.freesound.org/people/EdgardEdition


--USING the mod--
------------------

This mod inplements to new functions to the players inventory. The first is the breaking sound of any tool,
that is played when a tool breakes after the specific number of uses.

The second new function is Auto-refill. This function replaces broken tools or emptied stacks with others from your inventory.


You can disable the auto-refill by changing first line of init.lua to "local auto_refill = false"