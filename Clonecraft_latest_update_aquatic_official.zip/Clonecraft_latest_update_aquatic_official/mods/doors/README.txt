Minetest 0.4 mod: doors
=======================
version: 1.3

License of source code:
-----------------------
Copyright (C) 2012 PilzAdam
modified by BlockMen (added sounds, glassdoors[glass, obsidian glass], trapdoor)

This program is free software. It comes without any warranty, to
the extent permitted by applicable law. You can redistribute it
and/or modify it under the terms of the Do What The Fuck You Want
To Public License, Version 2, as published by Sam Hocevar. See
http://sam.zoy.org/wtfpl/COPYING for more details.

License of textures
--------------------------------------
following Textures created by Fernando Zapata (CC BY-SA 3.0):
  door_wood.png
  door_wood_a.png
  door_wood_a_r.png
  door_wood_b.png
  door_wood_b_r.png

following Textures created by BlockMen (WTFPL):
  door_trapdoor.png
  door_obsidian_glass_side.png

following textures created by celeron55 (CC BY-SA 3.0):
  door_trapdoor_side.png
  door_glass_a.png
  door_glass_b.png
  
following Textures created by PenguinDad (CC BY-SA 4.0):
  door_glass.png
  door_obsidian_glass.png

All other textures (created by PilzAdam): WTFPL


License of sounds
--------------------------------------
Opening-Sound created by CGEffex (CC BY 3.0), modified by BlockMen
  door_open.ogg
Closing-Sound created by bennstir (CC BY 3.0)
  door_close.ogg
