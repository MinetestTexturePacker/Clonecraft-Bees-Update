[mod] visible wielded items [wieldview]
=======================================

depends: default, unified_skins

Makes hand wielded items visible to other players. Compatible with player skins mod [skins].

Note: Currently only supports 16x16px texture packs, sorry!

default settings: [minetest.conf]

# Set number of seconds between visible wielded item updates.
wieldview_update_time = 2

# Show nodes as tiles, disabled by default
wieldview_node_tiles = false

